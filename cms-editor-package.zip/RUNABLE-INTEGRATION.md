# Runable integration handoff

This package is a deliberately minimal CMS editor for the existing Carl Nyvlt portfolio. The current source repository is `cnyvlt/CarlNyvltsPortfolio-4185`, using the `main` branch. It preserves the site's design by editing content fields only; it does not replace the portfolio frontend.

## What is included

- `cms-editor/` — responsive editor and preview UI, usable as a static prototype.
- `content-schema.json` — the content contract for a case study.
- Local browser draft storage, JSON import, and JSON export.

## Current boundary

The editor is **not connected** to Runable, the live website, a database, authentication, or backups. “Save draft” currently uses `localStorage` in the browser so the interaction can be reviewed safely. The portfolio currently stores content in TypeScript data files; its Turso/Drizzle template is present but has no active schema or CMS.

## Ask Runable to connect it

Please connect this editor to the existing portfolio while preserving the current frontend design, routes, CSS, media, and Runable deployment workflow. The live project is published with Runable's **Publish** button; do not assume a GitHub push deploys automatically:

1. Add a persistent Turso/Drizzle `case_studies` record using the fields in `content-schema.json`: `title`, `description`, `context`, `process`, and `outcome`. Add `slug`, `status` (`draft` or `published`), `created_at`, `updated_at`, and `published_at`. Apply the schema with the project's `db:push` workflow.
2. Add authenticated CMS access for one admin user, Carl, using the platform's secure auth/secrets facilities. Do not expose write endpoints to public visitors.
3. Keep the Turso URL and auth token in the root `.env` only, supplied through Runable's secure secrets form. Never commit or paste them into chat.
4. Replace the browser `localStorage` save path in `cms-editor/app.js` with the project's server/API calls. Keep JSON import/export as a manual backup path.
5. Add `Save draft`, `Preview`, and explicit `Publish` behavior. Preview should render the saved draft through the existing portfolio template without changing the public published version. The final production step remains Runable's **Publish** button.
6. Make the public portfolio read only the latest `published` record. Publishing should be an explicit action, not an autosave.
7. Add revision history or timestamped snapshots before each publish so an earlier version can be restored. Back up the database and content records on the platform's normal backup schedule.
8. Add S3-compatible image storage for CMS uploads after the bucket and credentials are confirmed. Keep image credentials in secure environment variables.
9. Preserve the current visual system and responsive behavior. Map the editor's five fields into the existing case-study layout; do not redesign the portfolio as part of this integration.
10. Verify: unauthenticated visitors cannot edit; draft changes are not public; preview matches the existing site; publish updates the intended case study; restore returns the previous content.

## Suggested API shape

```text
GET    /api/case-studies/:slug
PUT    /api/case-studies/:slug/draft
POST   /api/case-studies/:slug/publish
GET    /api/case-studies/:slug/revisions
POST   /api/case-studies/:slug/revisions/:revisionId/restore
```

Use the platform's managed database and secret/auth facilities where available. Do not commit credentials or hard-code a database connection string in this package.

## Handoff checklist

- [ ] Connect the private GitHub repository `cnyvlt/CarlNyvltsPortfolio-4185` through the approved GitHub integration.
- [ ] Confirm the current portfolio source and Runable deployment are backed up before integration.
- [ ] Confirm the existing case-study route and its data source.
- [ ] Create database migration and seed the current live content before enabling edits.
- [ ] Connect authenticated API calls and keep draft/published states separate.
- [ ] Test restore and rollback before enabling the publish button for production.
