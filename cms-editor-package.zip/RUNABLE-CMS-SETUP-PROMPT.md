# Runable CMS setup prompt

Copy the block below into the Runable project chat after uploading this package to the `cms-editor-preview` branch.

> Integrate the CMS package in this repository's root `cms-editor/` folder into the existing React portfolio. This is the editor package prepared in a separate Codex workspace; do not replace it with a different CMS design.
>
> Repository: `cnyvlt/CarlNyvltsPortfolio-4185`  
> Branch: `cms-editor-preview`  
> Production branch: `main`
>
> Preserve the existing portfolio routes, visual design, fonts, images, and responsive behavior. Move the editor into the appropriate admin page under `packages/web`, keeping its visual language and fields: Title, Description, Context, Process, and Outcome.
>
> Connect the editor to the existing Drizzle/Turso setup. Add authenticated Better Auth access for one admin user, draft and published states, revision history, preview, publish, and restore behavior. The public case-study and projects pages must read only published records. Draft changes must remain private.
>
> Keep Turso, Better Auth, and any future image-storage credentials in Runable's secure environment settings. Never commit secrets or request them in chat. Use the existing database commands and run typecheck, lint, build, and database checks.
>
> Prepare this in a preview environment only. Do not press Runable's final Publish button until the owner reviews and approves the preview.

## Owner actions after Runable prepares the preview

1. Confirm the private repository connection and `cms-editor-preview` branch.
2. Approve the Better Auth admin account for Carl.
3. Create or approve the Turso database.
4. Enter database and auth values into Runable's secure secrets form.
5. Review the preview and test draft, preview, publish, and restore.
6. Press Runable's Publish button only after approval.
